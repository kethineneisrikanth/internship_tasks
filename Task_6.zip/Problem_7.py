# # 6 Print Function
# https://www.hackerrank.com/challenges/python-print/problem

n=int(input())
s=""
for i in range(1,n+1):
    s=s+str(i)
print(s)
