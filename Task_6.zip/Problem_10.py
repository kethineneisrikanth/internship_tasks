# 10 Designer Door Mat
# https://www.hackerrank.com/challenges/designer-door-mat/problem

